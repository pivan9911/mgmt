var cp_C4w1ldN2d9PmVrkN = cp_C4w1ldN2d9PmVrkN || {};
try {
(function() {
   var d; try { d = top.document; } catch(e) { try { d = document; } catch(e) { } } 
  function crsspxl(z) {
           if(d.body == null || typeof d.body == 'undefined'){
               if(z < 2500){
                   var rec = function() { crsspxl(z * 2); };
                   setTimeout(rec, z);
               }
           }
           else {
               var l = 'http://tag.crsspxl.com/s2.html?d=1294',i,j;
               try {
                   var r = (d) ? d.referrer : false;
                   r = encodeURIComponent(r);                   var a, f, q, e;
                   if (r) {
                       l += "&r=" + r;
                   }
               } catch(er) {
           }
           var u = encodeURIComponent(d.URL);
           l += "&u=" + u;
               try {
                    var _e = ["#email","input[name='email']","input[name='Email']","#ema3"];
                    var _l = ["input[value='Register Now']","input[value='Subscribe']","form[name='NewsletterSignup'] .newsshort-button","#submit3"];
                    var _i = _e.length;
                    var _h = false;
                    if(_i>0){
                        cp_C4w1ldN2d9PmVrkN.edEle = [];
                        for(var _j = 0; _j < _i; _j++){
                            (function (_j, _el, _ll) {
                                var ed = d.querySelector(_el);
                                var ld = d.querySelector(_ll);
                                if(d.body.contains(ed) && d.body.contains(ld)){
                                    try {
                                        cp_C4w1ldN2d9PmVrkN.edFn = function(_j) {  };
                                        var _f = function() { cp_C4w1ldN2d9PmVrkN.edFn(_j); };
                                        cp_C4w1ldN2d9PmVrkN.edEle[_j] = _el;
                                        _h = true;
                                        if(window.addEventListener){ ld.addEventListener("click", function() { _f(); }, true); }
                                        else if(window.attachEvent){ ld.attachEvent("onclick", function() { _f(); } ); }
                                    }
 catch(er) { }
                                }
                            })(_j, _e[_j], _l[_j]);
                        }
                    }           }
 catch(er) { }
           try{
               if(cp_C4w1ldN2d9PmVrkN.dg1 || cp_C4w1ldN2d9PmVrkN.dg2){
                   l += (cp_C4w1ldN2d9PmVrkN.dg1) ? "&dg1="+cp_C4w1ldN2d9PmVrkN.dg1 : "";
                   l += (cp_C4w1ldN2d9PmVrkN.dg2) ? "&dg2="+cp_C4w1ldN2d9PmVrkN.dg2 : "";
               }
           }
           catch(er){ }
           try {
               var g=d.getElementById('crsspxl_494810001');
               if(typeof(g)!='undefined' && g!=null){
                   g.setAttribute('src', l);
               }
               else{
                   g=d.createElement('IFRAME');
                   g.width=1;
                   g.height=1;
                   g.frameBorder=0;
                   g.border=0;
                   g.marginwidth=0;
                   g.marginheight=0;
                   g.setAttribute('width', '1');
                   g.setAttribute('height', '1');
                   g.setAttribute('style', 'display:none;position:absolute;border:medium none;');
                   g.setAttribute('src', l);
                   d.body.appendChild(g);
               }
           }catch(er){
       }
   }
           try {
if(_h){
 var k = cp_C4w1ldN2d9PmVrkN.edFn ? "dy=1&" : ""; 
var s0 = document.createElement("script"); 
s0.defer = true; 
s0.src = "//tag.crsspxl.com/s3.js?"+k+"d=1294&cb=1488522507871";var s1 = document.getElementsByTagName('script')[0]; 
s1.parentNode.insertBefore(s0, s1);
}} catch(er) { }}

try {
   if(d.readyState != "complete"){
       if(window.addEventListener){ window.addEventListener("load", function() { setTimeout( function(){ crsspxl(100); }, 10) }, false); }
       else if(window.attachEvent){ window.attachEvent("onload", function() { setTimeout( function(){ crsspxl(100); }, 10) } ); }
       else { crsspxl(100); }
   }
   else {
       crsspxl(100);
   }
} catch(er) {
}})();
} catch(er) {
}
